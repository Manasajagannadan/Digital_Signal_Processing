# assignment-in-lab4-moving_avg_system_voice
Generate a voice of adding noise and check applying moving average system operation to check our original voice
1.take our voice
2.apply noise
3.add and apply moving avg system
4.observe the results in graph
5.run the code give in my page
