# lab7-dft_properties
To check the dft properties using python
run the given programs 
