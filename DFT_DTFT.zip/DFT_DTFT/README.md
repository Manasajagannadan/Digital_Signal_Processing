# lab-6-dft-and-dtft
to check the dft and dtft using python
run the codes given
