# matrix_multiplication-transpose_matrix
matrix multiplication and transpose of a matrix with python
1.Basic Python program using list
2.install python latest version for better results
NOte:-
for linux:-https://www.anaconda.com/download/#linux
for windows:-https://www.anaconda.com/download/#windows
for macOS:-https://www.anaconda.com/download/#macos
3.Run the code given in the zip file
