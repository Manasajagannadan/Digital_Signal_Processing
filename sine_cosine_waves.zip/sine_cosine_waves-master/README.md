# sine_cosine_waves
Generating sinusoidal and cosine waves using numpy and matplotlib
1.Basic program of generating sin and cos waves
3.Add those sine and cosine waves
2.install anacond version 
note:-
for linux:-https://www.anaconda.com/download/#linux
for windows:-https://www.anaconda.com/download/#windows
for macOS:-https://www.anaconda.com/download/#macos
3.Run the codes give in the downloaded zip file
