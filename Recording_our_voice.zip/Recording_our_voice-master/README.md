# lab-3--recording-our-voice
1.record our voice in terminal
note:-
command in terminal:-
      arecord -d 6 -r 16000 >sai.wav
2.save it in desktop
3.and run the codes what given in my page
4.see the result
5.plot the graphs and observe it
